<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class OcamController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function asesoriasAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function atencionkinesicaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function atencionprofesoresAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function atencionpsicologicaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function atencionsalonesAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function atencionsocialAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function atencionesocialAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function clasespersonalizadasAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function gestoresenterrenoAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }
}
