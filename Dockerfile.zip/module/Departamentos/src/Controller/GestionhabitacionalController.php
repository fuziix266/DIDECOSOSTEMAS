<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class GestionhabitacionalController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function adultomayorAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function constitucioncomiteAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function agrupacionculturalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function agrupaciondeportivaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function clubadultomayorAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function comiteviviendaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function fundacionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function juntavecinalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function ongAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function padresyapoderadosAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
}