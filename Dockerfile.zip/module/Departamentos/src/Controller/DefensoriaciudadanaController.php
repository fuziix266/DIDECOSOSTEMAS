<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class DefensoriaciudadanaController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function orientacionlegalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

}