<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class MujeryequidadController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function emprendimientoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function capacitacionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function pervencionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function terapiasAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function escritosAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function orientacionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function causasjudicialesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function denunciasAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function autorizacionesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function festivalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function denunciaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function deudorespensionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

}