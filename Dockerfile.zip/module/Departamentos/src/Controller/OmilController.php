<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class OmilController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function certificadocesantiaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function certificadoinscripcionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function cesantiasolidariaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function inscripcionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function postulacionAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function requerimientoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function solicituddiscapacidadAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }       

}