<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class SubsidioypensionesController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function pensionesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function aguapotableAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function sapruralAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function sapurbanoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function reciennacidoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function maternalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function bonoporhijoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function discapacidadAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function apsiAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function pbsiAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function pensioninvalidezAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function familiarduploAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function madreAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function menoresAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function pguAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function sufAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
}