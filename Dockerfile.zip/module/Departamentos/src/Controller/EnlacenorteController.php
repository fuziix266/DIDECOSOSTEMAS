<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class EnlacenorteController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');
        return new ViewModel();
    }

    //001
    public function subsidiofamiliarAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //002
    public function subsidiomaternalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //003
    public function subsidioreciennacidoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //004
    public function subsidiocesantiamenoresAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //005
    public function subsidiofamiliarduploAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //006
    public function subsidiomadreAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //007
    public function pensionesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //008
    public function pensionuniversalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //009
    public function pensioninvalidezAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //010
    public function bonoporhijoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //011
    public function juntasvecinalesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //012
    public function organizacionesfuncionalesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //013
    public function territorialesAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //014
    public function aporteinvalidezAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //015
    public function emergenciasAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //016
    public function comodatoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //017
    public function sapruralAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //018
    public function sapurbanoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //019
    public function subsidioaguaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    //020
    public function subsidiodiscapacidadAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
}