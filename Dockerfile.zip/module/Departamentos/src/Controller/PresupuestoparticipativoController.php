<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class PresupuestoparticipativoController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function fondeveAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function fondecoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function presupuestoparticipativoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

}
