<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class OlnController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function demandaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function proteccionuniversalAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function proteccionurgenciaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function promocionderechosnnaAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

}