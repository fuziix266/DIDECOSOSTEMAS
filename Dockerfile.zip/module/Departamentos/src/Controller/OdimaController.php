<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class OdimaController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function acreditacionindigenaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function becaindigenaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function informacionasociacionindigenaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function inscripcionasociacionindigenaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function microemprendimientoAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function subsidiohabitacionalAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function actividadestematicasAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }



}