<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class DerechoshumanosController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function capacitacionAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function diversidadsexualAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function lgbtAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function nacionalizacionAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function permanenciatransitoriaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function residenciadefinitivaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function residenciatemporalAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function vigenciacedulaAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }
}