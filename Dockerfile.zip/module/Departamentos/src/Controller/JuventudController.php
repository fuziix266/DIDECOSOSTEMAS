<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class JuventudController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function apoyoiniciativasAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function aprendeyemprendeAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }

    public function centrosdealumnosAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    
    public function voluntariadoAction()
    {
        $this->layout()->setTemplate('layout/servicios');
        return new ViewModel();
    }
    

}