<?php

namespace Departamentos\Controller;

use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;

class ServiciosocialController extends AbstractActionController
{
    public function indexAction()
    {
        $this->layout()->setTemplate('layout/menuservicios');

        return new ViewModel();
    }

    public function alimentosAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function materialesconstruccionAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function piezasprefabricadasAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function ayudasaludAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function pasajesAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function pagoserviciosAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function camionaljibeAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }

    public function canonarrendamientoAction()
    {
        $this->layout()->setTemplate('layout/servicios');

        return new ViewModel();
    }


}